     --- Elysium Diamond ---


Diamond In The Rough
by Raven Moonshadows


Gold is just a color
Diamonds only glitter
Glass is easy to shatter

Silk is just a fabric
Fur coats cause havoc
Lace? Associated with arsenic

Mansions require maids to clean
Satin has an annoying sheen
Of porcelain I'm not very keen

French poodles are too persnickety
Limousines too rickety
Strong perfume is smelly

Cash? I've no patience for greed
Gadgets are tricky, please take heed
Of fame I've no real need

But the truest friends are something rare
More desirable than riches, this I declare
Diamond in the rough- A person hard to snare

And in my mind, with you, nothing can compare

I hope you know how much I care




I'm proud to release Elysium Diamond. This is officially version v 1.1 but I'll refer to it as the first release.

Elysium Diamond is a free, 2D MMORPG maker created in Visual Basic 6. It's just the next version of Elysium Source and I see many games being created using this software. Feel free to edit the code to your heart's desire.

Elysium Diamond is covered under the EGL (Elysium General License). A copy of the license is included in the "Extras" folder.

If you paid money for this download, report it right away. Elysium Diamond is 100% free and the person who sold it can be charged for a crime. Do the same if a person other than pingu or an Elysium Source admin claims to have made this.

The official site can be reached at: http://www.splamm.com/elysium

And thus, I conclude the little introduction to Elysium Diamond. I've spent a long time making this version. I hope you know how much I care.


-- pingu
(pingu@splamm.com)